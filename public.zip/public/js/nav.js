const button = document.querySelector("#menu-button");
const menu = document.querySelector("#menu");
const menu_close = document.querySelector("#menu-close");
const hood = document.querySelector("#hood");

button.addEventListener("click", () => {
    menu.classList.toggle("hidden");
    menu.classList.toggle("flex");
    menu_close.style.display = 'block'
    button.style.display = 'none'

});


menu_close.addEventListener("click", () => {
    menu.classList.toggle("hidden");
    menu.classList.toggle("flex");
    menu_close.style.display = 'none'
    button.style.display = 'block'
});



document.getElementById("credit_card").addEventListener("click", displayCreditCardInfo);
document.getElementById("payment").addEventListener("click", displayPaymentCardInfo);
document.getElementById("card_benefits").addEventListener("click", displayCardBenefitsInfo);
document.getElementById("wallet").addEventListener("click", displayWalletsInfo);
document.getElementById("investment").addEventListener("click", displayInvestmentsCardInfo);

const investment_block = document.getElementById('investment_block');
const credit_block = document.getElementById('credit_block');
const payment_block = document.getElementById('payment_block');
const card_block = document.getElementById('card_block');
const wallet_block = document.getElementById('wallet_block');

const investment = document.getElementById('investment');
const credit_card = document.getElementById('credit_card');
const payment = document.getElementById('payment');
const card_benefits = document.getElementById('card_benefits');
const wallet = document.getElementById('wallet');


function displayCreditCardInfo(){
    investment_block.style.display = 'none'
    card_block.style.display = 'none'
    wallet_block.style.display = 'none'
    payment_block.style.display = 'none'
    credit_block.style.display = 'flex'

    investment.style.color = 'black'
    investment.style.textDecoration = 'none'

    card_benefits.style.color = 'black'
    card_benefits.style.textDecoration = 'none'

    payment.style.color = 'black'
    payment.style.textDecoration = 'none'

    wallet.style.color = 'black'
    wallet.style.textDecoration = 'none'

    credit_card.style.color = '#e53b24'
    credit_card.style.textDecoration = 'underline'
    credit_card.style.textUnderlineOffset = '8px'
    
}

function displayInvestmentsCardInfo(){
    investment_block.style.display = 'flex'
    credit_block.style.display = 'none'
    card_block.style.display = 'none'
    wallet_block.style.display = 'none'
    payment_block.style.display = 'none'
    
    credit_card.style.color = 'black'
    credit_card.style.textDecoration = 'none'

    card_benefits.style.color = 'black'
    card_benefits.style.textDecoration = 'none'

    payment.style.color = 'black'
    payment.style.textDecoration = 'none'

    wallet.style.color = 'black'
    wallet.style.textDecoration = 'none'

    investment.style.color = '#e53b24'
    investment.style.textDecoration = 'underline'
    investment.style.textUnderlineOffset = '8px'

    
}

function displayPaymentCardInfo(){
    investment_block.style.display = 'none'
    credit_block.style.display = 'none'
    card_block.style.display = 'none'
    wallet_block.style.display = 'none'
    payment_block.style.display = 'flex'

    payment.style.color = '#e53b24'
    payment.style.textDecoration = 'underline'
    payment.style.textUnderlineOffset = '8px'

    credit_card.style.color = 'black'
    credit_card.style.textDecoration = 'none'

    card_benefits.style.color = 'black'
    card_benefits.style.textDecoration = 'none'

    wallet.style.color = 'black'
    wallet.style.textDecoration = 'none'

    investment.style.color = 'black'
    investment.style.textDecoration = 'none'
    // investment.style.textUnderlineOffset = '8px'

    
}

function displayCardBenefitsInfo(){
    investment_block.style.display = 'none'
    credit_block.style.display = 'none'
    card_block.style.display = 'flex'
    wallet_block.style.display = 'none'
    payment_block.style.display = 'none'

    card_benefits.style.color = '#e53b24'
    card_benefits.style.textDecoration = 'underline'
    card_benefits.style.textUnderlineOffset = '8px'

    credit_card.style.color = 'black'
    credit_card.style.textDecoration = 'none'

    payment.style.color = 'black'
    payment.style.textDecoration = 'none'

    wallet.style.color = 'black'
    wallet.style.textDecoration = 'none'

    investment.style.color = 'black'
    investment.style.textDecoration = 'none'
    // investment.style.textUnderlineOffset = '8px'

    
}

function displayWalletsInfo(){
    investment_block.style.display = 'none'
    credit_block.style.display = 'none'
    card_block.style.display = 'none'
    wallet_block.style.display = 'flex'
    payment_block.style.display = 'none'

    wallet.style.color = '#e53b24'
    wallet.style.textDecoration = 'underline'
    wallet.style.textUnderlineOffset = '8px'

    credit_card.style.color = 'black'
    credit_card.style.textDecoration = 'none'

    payment.style.color = 'black'
    payment.style.textDecoration = 'none'

    card_benefits.style.color = 'black'
    card_benefits.style.textDecoration = 'none'

    investment.style.color = 'black'
    investment.style.textDecoration = 'none'
    // investment.style.textUnderlineOffset = '8px'

    
}



