<div {{$attributes->merge(['class' => 'bg-gray-50'])}}>
  {{$slot}}
</div>