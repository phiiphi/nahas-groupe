<x-layout>
    <div class="bg-gray-50">
        <x-feature/>

    </div>
    <x-profile/>
    <x-services/>


</x-layout>