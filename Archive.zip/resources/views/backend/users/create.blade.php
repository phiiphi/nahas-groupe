<x-admin>
    
</x-admin>