<x-admin>
    <div class="mt-24">
        <div class="flex justify-center items-center h-96">
            <div class="w-1/2 h-80 mx-2 bg-white rounded">

            </div>
            <div class="w-1/2 h-80 mx-2 bg-white rounded">

            </div>
        </div>
    </div>
    
</x-admin>