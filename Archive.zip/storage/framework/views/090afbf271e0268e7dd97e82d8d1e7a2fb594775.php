<header class="video-container">

    <!-- Video from coverr.co -->
    <video class="video-bg" autoplay muted loop>
        <source src="<?php echo e(asset('/video/hook.mp4')); ?>" type="video/mp4" />
        <source src="./hook.mp4" type="video/webm" />
    </video>
    <div class="video-overlay1 mt-24">
        <h1 class="text-4xl md:text-9xl font-sans font-bold text-white">We Build</h1>
        <h1 class="text-4xl md:text-9xl my-8 font-bold text-white">Your  Dreams</h1>
        <div class="flex flex-col justify-center items-center bg-white h-2 my-12 w-1/2 mx-2"> 
        </div>


        <div class="flex justify-center items-center mt-8">
          <div class="flex flex-col justify-center items-center bg-white h-40 w-1/2 mx-2">
            <i class="text-center text-4xl fa-sharp my-2 fa-solid fa-envelope text-blue-700"></i>       
            <p class="text-xl font-bold">Contact Us</p>   
          </div>
          <div class="flex flex-col justify-center items-center bg-white h-40 w-1/2 mx-2">
            <i class="text-center text-4xl fa-sharp fa-solid my-2 fa-bullseye text-blue-700"></i>       
            <p class="text-xl font-bold">Services</p>   
          </div>
          <div class="flex flex-col justify-center items-center bg-white h-40 w-1/2 mx-2">
            <i class="text-center text-4xl fa-sharp fa-solid my-2 fa-bullseye text-blue-700"></i>       
            <p class="text-xl font-bold">Services</p>   
          </div>
        </div>
        <div class="flex justify-center items-center mt-8">
          <div class="flex flex-col justify-center items-center bg-white h-40 w-1/2 mx-2">
            <i class="text-center text-4xl fa-sharp my-2 fa-solid fa-envelope text-blue-700"></i>       
            <p class="text-xl font-bold">Contact Us</p>   
          </div>
          <div class="flex flex-col justify-center items-center bg-white h-40 w-1/2 mx-2">
            <i class="text-center text-4xl fa-sharp fa-solid my-2 fa-bullseye text-blue-700"></i>       
            <p class="text-xl font-bold">Services</p>   
          </div>
          <div class="flex flex-col justify-center items-center bg-white h-40 w-1/2 mx-2">
            <i class="text-center text-4xl fa-sharp fa-solid my-2 fa-bullseye text-blue-700"></i>       
            <p class="text-xl font-bold">Services</p>   
          </div>
        </div>
        
        <div class="flex justify-center items-center w-full mt-16">
          <div class="flex justify-center mt-8 items-center border h-16 w-16 rounded-full">
            <i class="flex justify-center items-center  fa-sharp fa-solid fa-arrow-down text-2xl text-white"></i>        
          </div>

        </div>
 
       
    </div>

    



</header>
<?php /**PATH /Users/nahas/Desktop/gnahas-app/resources/views/components/video.blade.php ENDPATH**/ ?>