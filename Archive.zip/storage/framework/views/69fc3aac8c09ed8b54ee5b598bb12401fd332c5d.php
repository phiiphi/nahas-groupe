<div class="block md:flex h-full md:h-[52rem]">
    <div class="flex justify-center flex-col  text-black w-full md:w-1/2 bg-[#ffbb38] mb-2 md:mb-0 ">
        <div class="w-full ml-2 md:ml-14">
            <div class="h-2 w-16 bg-white animate-pulse rounded-full my-8"></div>
            <h1 class='text-3xl md:text-5xl font-bold text-white'>Mission Statement</h1>
            <p class="my-8 text-2xl text-gray-600">
                Fast Logisitics Security Company is a global logistics  provider, offering a professional, <br>  personalised service to meet and exceed the requirements of you and your  customer.
            </p>            
            <p class="my-8 text-2xl text-gray-600">
                Our in depth industry knowledge, combined with our timely responses, will ensure you receive the <br> most  competitive and comprehensive cargo care package.
                We pride ourselves on adding value <br> to your product, actively seeking to become an integral part of your  business.
            </p>
    

        </div>
      
    </div>
    <div class="flex justify-center flex-col text-gray-600 w-full md:w-1/2" >
            <img class="object-cover w-full overflow-hidden h-96 md:h-full" 
            src="<?php echo e(asset('images/slider1.jpeg')); ?>"
            alt="image" />
              <!-- <div class="button-left text-6xl uppercase">LOYAL BULLION SECURITY VAULT</div> -->

    </div>

</div>
<div class="block md:flex h-full md:h-[52rem]"> 
    <div class="flex justify-center flex-col text-gray-600 w-full md:w-1/2" >
            <img class="object-cover w-full overflow-hidden h-96 md:h-full" 
            src="<?php echo e(asset('images/slider1.jpeg')); ?>"
            alt="image" />
              <!-- <div class="button-left text-6xl uppercase">LOYAL BULLION SECURITY VAULT</div> -->

    </div>
    <div class="flex justify-center flex-col  text-black w-full md:w-1/2 bg-[#ffbb38] mb-2 md:mb-0 ">
        <div class="w-full ml-2 md:ml-14">
            <div class="h-2 w-16 bg-white animate-pulse rounded-full my-8"></div>
            <h1 class='text-3xl md:text-5xl font-bold text-white'>Mission Statement</h1>
            <p class="my-8 text-2xl text-gray-600">
                Fast Logisitics Security Company is a global logistics  provider, offering a professional, <br>  personalised service to meet and exceed the requirements of you and your  customer.
            </p>            
            <p class="my-8 text-2xl text-gray-600">
                Our in depth industry knowledge, combined with our timely responses, will ensure you receive the <br> most  competitive and comprehensive cargo care package.
                We pride ourselves on adding value <br> to your product, actively seeking to become an integral part of your  business.
            </p>
    

        </div>
      
    </div>

</div><?php /**PATH /Users/nahas/Desktop/gnahas-app/resources/views/components/services.blade.php ENDPATH**/ ?>