<div class=" fixed top-0 inset-x-0 z-10">
    <div class="hidden md:flex justify-between w-full h-40 bg-white hood ">
        <div class="flex justify-start items-center mx-6">
            <ul class="mx-4 pt-4 text-3xl md:flex md:justify-between md:pt-0 text-black">
                <li>
                  <a class="md:p-4 py-2 block hover:text-purple-400" 
                  href="<?php echo e(route('home')); ?>"
                    >Home</a
                  >
                </li>
                <li>
                  <a class="md:p-4 py-2 block hover:text-purple-400" 
                    href="<?php echo e(route('about')); ?>" 
                    >About Us</a
                  >
                </li>
                <li>
                  <a class="md:p-4 py-2 block hover:text-purple-400" 
                  href="<?php echo e(route('location')); ?>"
                    >Location</a
                  >
                </li>
                <li>
                  <a class="md:p-4 py-2 block  hover:text-purple-400" 
                  href="<?php echo e(route('contact')); ?>"
                    >Contact</a
                  >
                </li>
                <li>
                  <a class="md:p-4 py-2 block  hover:text-purple-400" 
                  href="<?php echo e(route('contact')); ?>"
                    >Careers</a
                  >
                </li>
                <li>
                    <a class="md:p-4 py-2 block  hover:text-purple-400" 
                    href="<?php echo e(route('contact')); ?>"
                      >FAQ's</a
                    >
                  </li>
            </ul>           
        </div>
        <div class="flex justify-end items-center mx-6">
          <ul class="mx-4 pt-4 text-3xl md:flex md:justify-between md:pt-0 text-black">
            <li>
              <a class="md:p-4 py-2 block border hover:text-purple-400" 
              href="<?php echo e(route('gallery')); ?>"
                >Gallery</a
              >
            </li>  
            <li class="flex justify-center items-center mx-10  border hover:border hover:border-black w-56">
                <a class="md:p-4 py-2 block hover:text-purple-400" 
                href="<?php echo e(route('login')); ?>"
                  >Login
                  </a
                >
                <i class="fa-sharp fa-solid fa-right-to-bracket"></i>
              </li>
            </ul>           
        </div>
    </div>
    <div class="bg-white">
        <div class="flex md:hidden justify-between w-full h-40 hood text-black">
            <div class="flex justify-start items-center mx-6">
                <p>Logo</p>
            </div>
            <div class="flex justify-end items-center mx-6">
              <i class="mr-8 text-4xl fa-solid fa-bars h-6 w-6 cursor-pointer md:hidden block" id="menu-button"></i>       
              <i class="mr-8 text-4xl fa-solid fa-xmark h-6 w-6 cursor-pointer hidden" id="menu-close"></i>
  
              
          </div>
        </div>
        <ul class="hidden text-right pr-8 bg-white  text-2xl md:justify-between md:pt-0 h-screen" id="menu">
          <div class="flex flex-col justify-center items-center border-gray-500 border-r-2 w-1/2">
            <li>
              <a class="md:p-4 py-2 block hover:text-purple-400" 
              href="<?php echo e(route('home')); ?>"
                >Home</a
              >
            </li>
            <li>
              <a class="md:p-4 py-2 block hover:text-purple-400" 
                href="<?php echo e(route('about')); ?>" 
                >About Us</a
              >
            </li>
            <li>
              <a class="md:p-4 py-2 block hover:text-purple-400" 
              href="<?php echo e(route('location')); ?>"
                >Location</a
              >
            </li>
            <li>
              <a class="md:p-4 py-2 block  hover:text-purple-400" 
              href="<?php echo e(route('contact')); ?>"
                >Contact</a
              >
            </li>
            <li>
                <a class="md:p-4 py-2 block  hover:text-purple-400" 
                href="<?php echo e(route('contact')); ?>"
                  >FAQ's</a
                >
              </li>
  
          </div>
        </ul> 
         
            
  
    </div>
</div><?php /**PATH /Users/nahas/Desktop/gnahas-app/resources/views/components/navbar.blade.php ENDPATH**/ ?>