<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4 sm:px-8 mt-24">
        <div class="py-8">
            <div>
              <h2 class="text-2xl font-semibold leading-tight">Trackings</h2>
            </div>
            <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
              <div
                class="inline-block min-w-full shadow-md rounded-lg overflow-hidden"
              >
              <?php if(count($product) > 0): ?>
                <table class="min-w-full leading-normal">
                  <thead>
                    <tr>
                      <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                      >
                        Price
                      </th>
                      <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                      >
                        Description
                      </th>
                      <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                      >
                        Status
                      </th>
                      <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                      >
                        Location
                      </th>
                      <th
                        class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider"
                      >
                        Action
                      </th>
                     
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tracking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <?php echo e($tracking->price); ?>

                      </td>
                      <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                      <?php echo e($tracking->description); ?>

                      </td>
                      <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                      <?php echo e($tracking->status); ?>

                      </td>
                      <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <?php echo e($tracking->location); ?>

                        </td>
                      <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                        <a href="/tracking/<?php echo e($tracking->id); ?>">
                            <button class="text-green-500">
                            <i class="fa-solid fa-pen-to-square"></i>
                                Edit
                            </button>
                        </a>
                        <form method="POST" action="/tracking/<?php echo e($tracking->id); ?>">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button class="text-red-500"><i class="fa-solid fa-trash"></i> Delete</button>
                        </form>
                       <!-- <button class="bg-red-300 h-8 w-20 mx-1 rounded">Delete</button> -->
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              <?php else: ?>
                <p class="text-danger text-center"> No Data Yet</p>
              <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

  <?php /**PATH /Users/nahas/Desktop/gnahas-app/resources/views/backend/products/index.blade.php ENDPATH**/ ?>