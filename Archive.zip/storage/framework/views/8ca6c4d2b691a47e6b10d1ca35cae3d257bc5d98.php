<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['product']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['product']); ?>
<?php foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'h-[38rem]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-[38rem]']); ?>
<div class="block md:flex justify-center h-full md:h-[40rem]">
  <div class="flex justify-center my-8">
      <div class="flex justify-center flex-col text-gray-600 w-full md:w-full" >
          <img class="object-cover w-full overflow-hidden h-60 md:h-full" 
          src="<?php echo e($product->image_one ? asset('storage/uploads/'. $product->image_one) : asset('/images/no-image.png')); ?>" alt="" />
          <div>
              <p class="text-center text-2xl my-2">
                  <?php echo e($product->price); ?>

              </p>
              <p class="text-center text-2xl my-2">
                  <i class="fa-solid fa-location-dot mr-2"></i><?php echo e($product->location); ?>

              </p>
              <p class="text-center text-2xl my-2">
                  <?php echo e($product->description); ?>

              </p>
              <p class="text-center text-2xl my-2">
                  <?php echo e($product->status); ?> 
              </p>
              <div class="flex justify-center items-center text-center text-2xl">
                <div class="flex justify-center items-center text-center w-1/3 h-12 border text-2xl">
                    <a href="/product/<?php echo e($product->id); ?>">Read More</a>

                </div>
              </div>

          </div>

      </div>
  </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /Users/nahas/Desktop/gnahas-app/resources/views/components/listing-card.blade.php ENDPATH**/ ?>