<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h2 class="flex justify-center my-8 h-24 text-6xl font-sans">FEATURES</h2>
    <div class="block md:flex justify-center h-full md:h-[65rem] w-full">
        <div class="w-4/6 mx-4">
            <div class="flex justify-center flex-col text-gray-600 w-full" >
                <img class="object-cover w-full overflow-hidden h-[40rem]" 
                    src="<?php echo e($product->image_one ? asset('storage/uploads/'. $product->image_one) : asset('/images/no-image.png')); ?>" alt="" />

            </div>
            <div class="flex justify-center w-full my-8">
                <div class="flex justify-center flex-col text-gray-600 w-full md:w-1/2" >
                    <img class="object-cover w-full overflow-hidden h-44" 
                        src="<?php echo e($product->image_one ? asset('storage/uploads/'. $product->image_two) : asset('/images/no-image.png')); ?>" alt="" />

                </div>
                <div class="flex justify-center flex-col text-gray-600 w-full md:w-1/2 mx-4" >
                    <img class="object-cover w-full overflow-hidden h-44" 
                    src="<?php echo e($product->image_two ? asset('storage/uploads/'. $product->image_three) : asset('/images/no-image.png')); ?>" alt="" />

                </div>
                <div class="flex justify-center flex-col text-gray-600 w-full md:w-1/2" >
                    <img class="object-cover w-full overflow-hidden h-44" 
                        src="<?php echo e($product->image_one ? asset('storage/uploads/'. $product->image_four) : asset('/images/no-image.png')); ?>" alt="" />

                </div>
            </div>
        </div>
        <div class="w-2/6 mx-4">
            <div class="flex flex-col justify-center items-center shadow-md bg-white h-64">
                <p class="text-center text-6xl"><?php echo e($product->price); ?></p>
                <p class="text-center text-2xl my-2">
                    <i class="fa-solid fa-location-dot mr-2"></i><?php echo e($product->location); ?>

                </p> 
                <p class="text-center text-2xl my-2">
                    <?php echo e($product->description); ?>

                </p>
                <p class="text-center text-2xl my-2">
                    <?php echo e($product->status); ?>

                </p>
            </div>
            <div class="flex flex-col justify-center items-center shadow-md bg-white h-96 my-6">
                <p></p>
                <p class="p-4 text-2xl">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ad, culpa. Fugit asperiores laboriosam adipisci perspiciatis voluptas! Quam nostrum quod, aut fugiat assumenda ipsam provident cumque possimus repudiandae quibusdam quisquam illo!
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ad, culpa. Fugit asperiores laboriosam adipisci perspiciatis voluptas! Quam nostrum quod, aut fugiat assumenda ipsam provident cumque possimus repudiandae quibusdam quisquam illo!
                </p>
                
            </div>

            <div class="flex flex-col justify-center items-center shadow-md bg-white h-40">
                <button class="h-20 w-96 border bg-laravel rounded text-xl">Contact Us</button> 
            </div>



        </div>
    </div>

    <div class="w-full md:mx-2 mt-14 md:w-1/3 shadow-lg max-h-72">
        <div class="relative overflow-hidden mt-4 max-w-full w-full h-72" style="padding-bottom: 56.25%">
            <iframe
            src="https://www.youtube.com/embed/<?php echo e($product->status); ?>"
                frameborder="0"
                allowfullscreen
                class="absolute top-0 left-0 w-full h-full"
            >
        </iframe>
        </div>
    </div>
    
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /Users/nahas/Desktop/gnahas-app/resources/views/backend/products/show.blade.php ENDPATH**/ ?>