<div <?php echo e($attributes->merge(['class' => 'bg-gray-50'])); ?>>
  <?php echo e($slot); ?>

</div><?php /**PATH /Users/nahas/Desktop/gnahas-app/resources/views/components/card.blade.php ENDPATH**/ ?>